import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import MapContainer from "@/components/map-container";
import QuerySidebar from "@/components/query-sidebar";
import DashboardPanels from "@/components/dashboard-panels";
import DataTable from "@/components/data-table";
import ExportModal from "@/components/export-modal";
import { useWebSocket } from "@/hooks/use-websocket";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Satellite, Download, User } from "lucide-react";

export default function Dashboard() {
  const [isRealtime, setIsRealtime] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [queryParams, setQueryParams] = useState({});

  const { isConnected, lastMessage } = useWebSocket();

  const { data: stats } = useQuery({
    queryKey: ['/api/stats'],
    refetchInterval: isRealtime ? 5000 : false,
  });

  const { data: networks = [], refetch: refetchNetworks } = useQuery({
    queryKey: ['/api/networks', queryParams],
    refetchInterval: isRealtime ? 10000 : false,
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ['/api/alerts', { resolved: false, limit: 10 }],
    refetchInterval: isRealtime ? 5000 : false,
  });

  const handleQueryExecute = (params: any) => {
    setQueryParams(params);
    refetchNetworks();
  };

  return (
    <div className="min-h-screen bg-dark text-slate-50">
      {/* Mobile-Responsive Header */}
      <header className="bg-surface border-b border-surface-light h-16 sm:h-16 flex items-center justify-between px-4 sm:px-6 fixed top-0 left-0 right-0 z-50">
        <div className="flex items-center space-x-2 sm:space-x-4">
          <div className="flex items-center space-x-2 sm:space-x-3">
            <Satellite className="text-primary text-lg sm:text-xl" />
            <h1 className="text-base sm:text-xl font-semibold hidden sm:block">WiGLE Spatial Analytics</h1>
            <h1 className="text-base font-semibold sm:hidden">WiGLE</h1>
          </div>
          
          <div className="hidden sm:flex items-center space-x-2 text-sm">
            <Badge variant={isConnected ? "default" : "destructive"} className="bg-success/20 text-success">
              <div className="w-2 h-2 bg-success rounded-full mr-1" />
              {isConnected ? "Connected" : "Disconnected"}
            </Badge>
            <span className="text-slate-400">|</span>
            <span className="text-slate-400">
              DB: <span className="text-slate-300">sigint_forensics</span>
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-4">
          <div className="hidden sm:flex items-center space-x-2">
            <label className="text-sm text-slate-400">Real-time</label>
            <Switch 
              checked={isRealtime} 
              onCheckedChange={setIsRealtime}
              data-testid="toggle-realtime"
            />
          </div>

          <Button 
            onClick={() => setIsExportModalOpen(true)}
            className="bg-secondary hover:bg-secondary/80 h-10 sm:h-10"
            size={window.innerWidth < 640 ? "sm" : "default"}
            data-testid="button-export"
          >
            <Download className="w-4 h-4 sm:mr-2" />
            <span className="hidden sm:inline">Export</span>
          </Button>

          <Button 
            size="icon" 
            className="w-10 h-10 sm:w-8 sm:h-8 bg-primary rounded-full"
            data-testid="button-user"
          >
            <User className="w-5 h-5 sm:w-4 sm:h-4" />
          </Button>
        </div>
      </header>

      <div className="pt-16 flex flex-col sm:flex-row h-screen">
        <div className="sm:hidden bg-surface border-b border-surface-light p-2">
          <Badge variant={isConnected ? "default" : "destructive"} className="bg-success/20 text-success mr-4">
            <div className="w-2 h-2 bg-success rounded-full mr-1" />
            {isConnected ? "Connected" : "Disconnected"}
          </Badge>
          <span className="text-slate-400 text-sm">
            DB: <span className="text-slate-300">sigint_forensics</span>
          </span>
        </div>
        
        <QuerySidebar 
          onQueryExecute={handleQueryExecute}
          stats={stats}
        />

        <main className="flex-1 flex flex-col min-h-0">
          <MapContainer 
            networks={networks}
            alerts={alerts}
          />
          
          <div className="hidden sm:block">
            <DashboardPanels 
              networks={networks}
              alerts={alerts}
              stats={stats}
            />
            
            <DataTable 
              networks={networks}
              onExport={() => setIsExportModalOpen(true)}
            />
          </div>
        </main>
      </div>

      <ExportModal 
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        queryParams={queryParams}
      />
    </div>
  );
}
