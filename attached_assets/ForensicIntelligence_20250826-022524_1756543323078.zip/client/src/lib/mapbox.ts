import mapboxgl from 'mapbox-gl';
import type { Network } from "@shared/schema";

// Note: In a real application, this would be an environment variable
const MAPBOX_ACCESS_TOKEN = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN || 'your_mapbox_token_here';

mapboxgl.accessToken = MAPBOX_ACCESS_TOKEN;

export function initializeMap(container: HTMLElement, style: string = 'dark'): mapboxgl.Map {
  const map = new mapboxgl.Map({
    container,
    style: `mapbox://styles/mapbox/${style}-v11`,
    center: [-74.0060, 40.7128], // NYC default
    zoom: 10,
    bearing: 0,
    pitch: 0
  });

  // Add navigation controls
  map.addControl(new mapboxgl.NavigationControl(), 'top-left');

  return map;
}

export function addNetworkLayer(map: mapboxgl.Map) {
  map.on('load', () => {
    // Add network points source
    map.addSource('networks', {
      type: 'geojson',
      data: {
        type: 'FeatureCollection',
        features: []
      },
      cluster: true,
      clusterMaxZoom: 14,
      clusterRadius: 50
    });

    // Add cluster circles
    map.addLayer({
      id: 'clusters',
      type: 'circle',
      source: 'networks',
      filter: ['has', 'point_count'],
      paint: {
        'circle-color': [
          'step',
          ['get', 'point_count'],
          '#51bbd6',
          100,
          '#f1c40f',
          750,
          '#e74c3c'
        ],
        'circle-radius': [
          'step',
          ['get', 'point_count'],
          20,
          100,
          30,
          750,
          40
        ]
      }
    });

    // Add cluster count labels
    map.addLayer({
      id: 'cluster-count',
      type: 'symbol',
      source: 'networks',
      filter: ['has', 'point_count'],
      layout: {
        'text-field': '{point_count_abbreviated}',
        'text-font': ['DIN Offc Pro Medium', 'Arial Unicode MS Bold'],
        'text-size': 12
      },
      paint: {
        'text-color': '#ffffff'
      }
    });

    // Add individual points
    map.addLayer({
      id: 'unclustered-point',
      type: 'circle',
      source: 'networks',
      filter: ['!', ['has', 'point_count']],
      paint: {
        'circle-color': [
          'case',
          ['==', ['get', 'security'], 'Open'], '#e74c3c',
          ['==', ['get', 'security'], 'WEP'], '#f39c12',
          '#27ae60'
        ],
        'circle-radius': 6,
        'circle-stroke-width': 1,
        'circle-stroke-color': '#fff'
      }
    });

    // Add heat map layer
    map.addLayer({
      id: 'networks-heat',
      type: 'heatmap',
      source: 'networks',
      maxzoom: 9,
      paint: {
        'heatmap-weight': [
          'interpolate',
          ['linear'],
          ['get', 'signalStrength'],
          -100, 0,
          -20, 1
        ],
        'heatmap-intensity': [
          'interpolate',
          ['linear'],
          ['zoom'],
          0, 1,
          9, 3
        ],
        'heatmap-color': [
          'interpolate',
          ['linear'],
          ['heatmap-density'],
          0, 'rgba(33,102,172,0)',
          0.2, 'rgb(103,169,207)',
          0.4, 'rgb(209,229,240)',
          0.6, 'rgb(253,219,199)',
          0.8, 'rgb(239,138,98)',
          1, 'rgb(178,24,43)'
        ],
        'heatmap-radius': [
          'interpolate',
          ['linear'],
          ['zoom'],
          0, 2,
          9, 20
        ],
        'heatmap-opacity': [
          'interpolate',
          ['linear'],
          ['zoom'],
          7, 1,
          9, 0
        ]
      }
    }, 'waterway-label');

    // Click handlers
    map.on('click', 'clusters', (e) => {
      const features = map.queryRenderedFeatures(e.point, {
        layers: ['clusters']
      });
      const clusterId = features[0].properties?.cluster_id;
      const source = map.getSource('networks') as mapboxgl.GeoJSONSource;
      
      source.getClusterExpansionZoom(clusterId, (err, zoom) => {
        if (err) return;
        
        map.easeTo({
          center: (features[0].geometry as any).coordinates,
          zoom: zoom
        });
      });
    });

    map.on('click', 'unclustered-point', (e) => {
      const coordinates = (e.features![0].geometry as any).coordinates.slice();
      const properties = e.features![0].properties!;
      
      // Create popup content
      const popupContent = `
        <div class="p-2">
          <h3 class="font-semibold">${properties.ssid || '(hidden)'}</h3>
          <p class="text-sm text-gray-600">BSSID: ${properties.bssid}</p>
          <p class="text-sm">Signal: ${properties.signalStrength || 'Unknown'} dBm</p>
          <p class="text-sm">Security: ${properties.security || 'Unknown'}</p>
          <p class="text-sm">Frequency: ${properties.frequency || 'Unknown'}</p>
        </div>
      `;
      
      new mapboxgl.Popup()
        .setLngLat(coordinates)
        .setHTML(popupContent)
        .addTo(map);
    });

    // Change cursor on hover
    map.on('mouseenter', 'clusters', () => {
      map.getCanvas().style.cursor = 'pointer';
    });
    
    map.on('mouseleave', 'clusters', () => {
      map.getCanvas().style.cursor = '';
    });
    
    map.on('mouseenter', 'unclustered-point', () => {
      map.getCanvas().style.cursor = 'pointer';
    });
    
    map.on('mouseleave', 'unclustered-point', () => {
      map.getCanvas().style.cursor = '';
    });
  });
}

export function updateNetworkData(
  map: mapboxgl.Map, 
  networks: Network[], 
  layers: { accessPoints: boolean; heatMap: boolean; clusters: boolean }
) {
  const source = map.getSource('networks') as mapboxgl.GeoJSONSource;
  
  if (source) {
    const features = networks
      .filter(network => network.latitude && network.longitude)
      .map(network => ({
        type: 'Feature' as const,
        geometry: {
          type: 'Point' as const,
          coordinates: [parseFloat(network.longitude!), parseFloat(network.latitude!)]
        },
        properties: {
          id: network.id,
          ssid: network.ssid,
          bssid: network.bssid,
          signalStrength: network.signalStrength,
          security: network.security,
          frequency: network.frequency,
          lastSeen: network.lastSeen
        }
      }));

    source.setData({
      type: 'FeatureCollection',
      features
    });

    // Toggle layer visibility based on layer controls
    map.setLayoutProperty('unclustered-point', 'visibility', layers.accessPoints ? 'visible' : 'none');
    map.setLayoutProperty('clusters', 'visibility', layers.clusters ? 'visible' : 'none');
    map.setLayoutProperty('cluster-count', 'visibility', layers.clusters ? 'visible' : 'none');
    map.setLayoutProperty('networks-heat', 'visibility', layers.heatMap ? 'visible' : 'none');
  }
}
