import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Download, X } from "lucide-react";

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  queryParams: any;
}

export default function ExportModal({ isOpen, onClose, queryParams }: ExportModalProps) {
  const [format, setFormat] = useState("csv");
  const [options, setOptions] = useState({
    includeGeometry: true,
    includeTemporal: false,
    includeMetadata: false,
  });

  const { toast } = useToast();

  const exportMutation = useMutation({
    mutationFn: async (exportData: any) => {
      const response = await apiRequest("POST", "/api/export", exportData);
      return response.json();
    },
    onSuccess: (data) => {
      // Create download link
      let blob: Blob;
      let filename: string;

      switch (format) {
        case 'geojson':
          blob = new Blob([JSON.stringify(data.data, null, 2)], { type: 'application/geo+json' });
          filename = `wigle-export-${Date.now()}.geojson`;
          break;
        case 'csv':
          blob = new Blob([data.data], { type: 'text/csv' });
          filename = `wigle-export-${Date.now()}.csv`;
          break;
        case 'json':
          blob = new Blob([JSON.stringify(data.data, null, 2)], { type: 'application/json' });
          filename = `wigle-export-${Date.now()}.json`;
          break;
        default:
          blob = new Blob([JSON.stringify(data.data, null, 2)], { type: 'application/json' });
          filename = `wigle-export-${Date.now()}.json`;
      }

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast({
        title: "Export Complete",
        description: `Data exported successfully as ${format.toUpperCase()}`,
      });

      onClose();
    },
    onError: (error) => {
      toast({
        title: "Export Failed",
        description: "Failed to export data. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleExport = () => {
    exportMutation.mutate({
      format,
      includeGeometry: options.includeGeometry,
      includeTemporal: options.includeTemporal,
      includeMetadata: options.includeMetadata,
      queryParams,
    });
  };

  const handleOptionChange = (option: string, checked: boolean) => {
    setOptions(prev => ({
      ...prev,
      [option]: checked
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-surface border-surface-light max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-semibold">Export Data</DialogTitle>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onClose}
              className="text-slate-400 hover:text-slate-200"
              data-testid="button-close-modal"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label className="text-sm font-medium text-slate-300 mb-2">Export Format</Label>
            <Select value={format} onValueChange={setFormat} data-testid="select-export-format">
              <SelectTrigger className="w-full bg-dark border-surface-light">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">CSV</SelectItem>
                <SelectItem value="geojson">GeoJSON</SelectItem>
                <SelectItem value="json">JSON</SelectItem>
                <SelectItem value="kml">KML</SelectItem>
                <SelectItem value="shapefile">Shapefile</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm font-medium text-slate-300 mb-2">Include</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="includeGeometry"
                  checked={options.includeGeometry}
                  onCheckedChange={(checked) => handleOptionChange('includeGeometry', checked as boolean)}
                  data-testid="checkbox-include-geometry"
                />
                <Label htmlFor="includeGeometry" className="text-sm">Spatial geometries</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="includeTemporal"
                  checked={options.includeTemporal}
                  onCheckedChange={(checked) => handleOptionChange('includeTemporal', checked as boolean)}
                  data-testid="checkbox-include-temporal"
                />
                <Label htmlFor="includeTemporal" className="text-sm">Temporal data</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="includeMetadata"
                  checked={options.includeMetadata}
                  onCheckedChange={(checked) => handleOptionChange('includeMetadata', checked as boolean)}
                  data-testid="checkbox-include-metadata"
                />
                <Label htmlFor="includeMetadata" className="text-sm">Analysis metadata</Label>
              </div>
            </div>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button 
              onClick={handleExport}
              disabled={exportMutation.isPending}
              className="flex-1 bg-primary hover:bg-primary/80"
              data-testid="button-start-export"
            >
              <Download className="w-4 h-4 mr-2" />
              {exportMutation.isPending ? "Exporting..." : "Export"}
            </Button>
            <Button 
              variant="outline"
              onClick={onClose}
              className="px-4 border-surface-light hover:bg-surface-light"
              data-testid="button-cancel-export"
            >
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
