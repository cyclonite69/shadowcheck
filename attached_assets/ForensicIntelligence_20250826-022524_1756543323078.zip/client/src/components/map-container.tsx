import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { initializeMap, addNetworkLayer, updateNetworkData } from "@/lib/mapbox";
import type { Network, DetectionAlert } from "@shared/schema";

interface MapContainerProps {
  networks: Network[];
  alerts: DetectionAlert[];
}

export default function MapContainer({ networks, alerts }: MapContainerProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const [mapStyle, setMapStyle] = useState("dark");
  const [layers, setLayers] = useState({
    accessPoints: true,
    heatMap: true,
    clusters: false,
  });
  const [coordinates, setCoordinates] = useState("40.7128, -74.0060");

  useEffect(() => {
    if (mapContainerRef.current && !mapRef.current) {
      const map = initializeMap(mapContainerRef.current, mapStyle);
      mapRef.current = map;

      // Add event listeners
      map.on('mousemove', (e: any) => {
        setCoordinates(`${e.lngLat.lat.toFixed(4)}, ${e.lngLat.lng.toFixed(4)}`);
      });

      // Add network layer
      addNetworkLayer(map);
    }
  }, []);

  useEffect(() => {
    if (mapRef.current) {
      updateNetworkData(mapRef.current, networks, layers);
    }
  }, [networks, layers]);

  useEffect(() => {
    if (mapRef.current) {
      mapRef.current.setStyle(`mapbox://styles/mapbox/${mapStyle}-v11`);
    }
  }, [mapStyle]);

  const handleLayerToggle = (layerName: string, checked: boolean) => {
    setLayers(prev => ({
      ...prev,
      [layerName]: checked
    }));
  };

  return (
    <div className="flex-1 relative">
      {/* Mobile-Optimized Map Controls */}
      <div className="absolute top-4 right-4 z-10 space-y-2 sm:space-y-2">
        <Card className="bg-surface/90 backdrop-blur p-3 sm:p-4">
          <Label className="text-sm sm:text-xs text-slate-300 mb-3 sm:mb-2 block">Map Style</Label>
          <Select value={mapStyle} onValueChange={setMapStyle} data-testid="select-map-style">
            <SelectTrigger className="w-32 h-10 sm:w-24 sm:h-8 text-sm sm:text-xs bg-dark border-surface-light">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="dark">Dark</SelectItem>
              <SelectItem value="light">Light</SelectItem>
              <SelectItem value="satellite">Satellite</SelectItem>
              <SelectItem value="streets">Streets</SelectItem>
            </SelectContent>
          </Select>
        </Card>

        <Card className="bg-surface/90 backdrop-blur p-3 sm:p-3">
          <Label className="text-sm sm:text-xs text-slate-300 mb-3 sm:mb-2 block">Layers</Label>
          <div className="space-y-3 sm:space-y-2">
            <div className="flex items-center space-x-3 sm:space-x-2">
              <Checkbox 
                id="accessPoints"
                checked={layers.accessPoints}
                onCheckedChange={(checked) => handleLayerToggle('accessPoints', checked as boolean)}
                data-testid="checkbox-access-points"
                className="h-5 w-5 sm:h-4 sm:w-4"
              />
              <Label htmlFor="accessPoints" className="text-sm sm:text-xs cursor-pointer">Access Points</Label>
            </div>
            <div className="flex items-center space-x-3 sm:space-x-2">
              <Checkbox 
                id="heatMap"
                checked={layers.heatMap}
                onCheckedChange={(checked) => handleLayerToggle('heatMap', checked as boolean)}
                data-testid="checkbox-heat-map"
                className="h-5 w-5 sm:h-4 sm:w-4"
              />
              <Label htmlFor="heatMap" className="text-sm sm:text-xs cursor-pointer">Heat Map</Label>
            </div>
            <div className="flex items-center space-x-3 sm:space-x-2">
              <Checkbox 
                id="clusters"
                checked={layers.clusters}
                onCheckedChange={(checked) => handleLayerToggle('clusters', checked as boolean)}
                data-testid="checkbox-clusters"
                className="h-5 w-5 sm:h-4 sm:w-4"
              />
              <Label htmlFor="clusters" className="text-sm sm:text-xs cursor-pointer">Clusters</Label>
            </div>
          </div>
        </Card>
      </div>

      {/* Map Container */}
      <div 
        ref={mapContainerRef} 
        className="w-full h-full bg-dark"
        data-testid="map-container"
      />

      {/* Map Attribution */}
      <div className="absolute bottom-2 left-2 text-xs text-slate-400">
        © Mapbox © PostgreSQL/PostGIS
      </div>

      {/* Coordinates Display */}
      <div className="absolute bottom-2 right-2 bg-surface/80 backdrop-blur rounded px-2 py-1 text-xs">
        <span data-testid="text-coordinates">{coordinates}</span>
      </div>
    </div>
  );
}
