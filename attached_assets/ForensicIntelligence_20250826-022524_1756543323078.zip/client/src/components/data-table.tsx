import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download } from "lucide-react";
import type { Network } from "@shared/schema";

interface DataTableProps {
  networks: Network[];
  onExport: () => void;
}

export default function DataTable({ networks, onExport }: DataTableProps) {
  const getSignalColor = (signal: number | null) => {
    if (!signal) return "secondary";
    if (signal >= -50) return "default"; // Strong - green
    if (signal >= -70) return "secondary"; // Medium - yellow
    return "destructive"; // Weak - red
  };

  const getSignalText = (signal: number | null) => {
    if (!signal) return "Unknown";
    return `${signal} dBm`;
  };

  const formatFrequency = (frequency: string | null) => {
    if (!frequency) return "Unknown";
    const freq = parseFloat(frequency);
    if (freq >= 5000) return "5 GHz";
    if (freq >= 2400) return "2.4 GHz";
    return `${freq} MHz`;
  };

  const formatLastSeen = (lastSeen: Date | string | null) => {
    if (!lastSeen) return "Unknown";
    const now = new Date();
    const past = new Date(lastSeen);
    const diffMs = now.getTime() - past.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)} hrs ago`;
    return `${Math.floor(diffMins / 1440)} days ago`;
  };

  const formatLocation = (lat: string | null, lng: string | null) => {
    if (!lat || !lng) return "Unknown";
    return `${parseFloat(lat).toFixed(4)}, ${parseFloat(lng).toFixed(4)}`;
  };

  return (
    <div className="h-64 bg-surface border-t border-surface-light">
      <div className="flex items-center justify-between p-4 border-b border-surface-light">
        <h3 className="text-sm font-semibold">Query Results</h3>
        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-400">
            <span data-testid="text-results-count">{networks.length.toLocaleString()}</span> records found
          </span>
          <Button 
            size="sm"
            variant="outline"
            onClick={onExport}
            className="text-xs bg-surface-light hover:bg-slate-600 border-surface-light"
            data-testid="button-export-csv"
          >
            <Download className="w-3 h-3 mr-1" />
            Export CSV
          </Button>
        </div>
      </div>

      <div className="overflow-auto h-full">
        <table className="w-full text-xs">
          <thead className="bg-surface-light sticky top-0">
            <tr>
              <th className="text-left p-2 font-medium">SSID</th>
              <th className="text-left p-2 font-medium">BSSID</th>
              <th className="text-left p-2 font-medium">Signal</th>
              <th className="text-left p-2 font-medium">Security</th>
              <th className="text-left p-2 font-medium">Frequency</th>
              <th className="text-left p-2 font-medium">Location</th>
              <th className="text-left p-2 font-medium">Last Seen</th>
            </tr>
          </thead>
          <tbody>
            {networks.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-8 text-center text-slate-400">
                  No networks found. Try adjusting your query parameters.
                </td>
              </tr>
            ) : (
              networks.map((network, index) => (
                <tr 
                  key={network.id} 
                  className="border-b border-surface-light hover:bg-surface-light/30"
                  data-testid={`row-network-${index}`}
                >
                  <td className="p-2" data-testid={`text-ssid-${index}`}>
                    {network.ssid || "(hidden)"}
                  </td>
                  <td className="p-2 font-mono text-slate-400" data-testid={`text-bssid-${index}`}>
                    {network.bssid}
                  </td>
                  <td className="p-2">
                    <Badge 
                      variant={getSignalColor(network.signalStrength)}
                      className="text-xs"
                      data-testid={`badge-signal-${index}`}
                    >
                      {getSignalText(network.signalStrength)}
                    </Badge>
                  </td>
                  <td className="p-2" data-testid={`text-security-${index}`}>
                    {network.security || "Unknown"}
                  </td>
                  <td className="p-2" data-testid={`text-frequency-${index}`}>
                    {formatFrequency(network.frequency)}
                  </td>
                  <td className="p-2 font-mono text-xs text-slate-400" data-testid={`text-location-${index}`}>
                    {formatLocation(network.latitude, network.longitude)}
                  </td>
                  <td className="p-2 text-slate-400" data-testid={`text-last-seen-${index}`}>
                    {formatLastSeen(network.lastSeen)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
