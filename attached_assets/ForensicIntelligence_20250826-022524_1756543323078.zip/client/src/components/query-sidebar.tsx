import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Search } from "lucide-react";

interface QuerySidebarProps {
  onQueryExecute: (params: any) => void;
  stats?: {
    totalNetworks: number;
    activeNetworks: number;
    coverageArea: number;
    securityDistribution: { [key: string]: number };
  };
}

export default function QuerySidebar({ onQueryExecute, stats }: QuerySidebarProps) {
  const [queryType, setQueryType] = useState("proximity");
  const [bounds, setBounds] = useState({
    north: "",
    south: "",
    east: "",
    west: ""
  });
  const [filters, setFilters] = useState({
    signalMin: "",
    signalMax: "",
    security: [] as string[],
    timeRange: "24h"
  });

  const handleExecuteQuery = () => {
    const params: any = {};
    
    // Add bounds if provided
    if (bounds.north && bounds.south && bounds.east && bounds.west) {
      params.north = parseFloat(bounds.north);
      params.south = parseFloat(bounds.south);
      params.east = parseFloat(bounds.east);
      params.west = parseFloat(bounds.west);
    }

    // Add signal filters
    if (filters.signalMin) params.signalMin = parseInt(filters.signalMin);
    if (filters.signalMax) params.signalMax = parseInt(filters.signalMax);
    
    // Add security filters
    if (filters.security.length > 0) params.security = filters.security;

    onQueryExecute(params);
  };

  const handleSecurityToggle = (security: string, checked: boolean) => {
    setFilters(prev => ({
      ...prev,
      security: checked 
        ? [...prev.security, security]
        : prev.security.filter(s => s !== security)
    }));
  };

  return (
    <aside className="w-full sm:w-80 bg-surface border-r border-surface-light flex flex-col max-h-screen overflow-y-auto">
      <div className="p-4 border-b border-surface-light">
        <h2 className="text-lg font-semibold mb-4">Query Builder</h2>
        
        <div className="space-y-4">
          <div>
            <Label className="text-sm font-medium text-slate-300 mb-2">Dataset</Label>
            <Select defaultValue="live" data-testid="select-dataset">
              <SelectTrigger className="w-full bg-dark border-surface-light text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="live">Full Dataset (Live)</SelectItem>
                <SelectItem value="historical">Historical Archive</SelectItem>
                <SelectItem value="filtered">Filtered Subset</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm font-medium text-slate-300 mb-2">Query Type</Label>
            <Select value={queryType} onValueChange={setQueryType} data-testid="select-query-type">
              <SelectTrigger className="w-full bg-dark border-surface-light text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="proximity">Proximity Analysis</SelectItem>
                <SelectItem value="intersection">Intersection Query</SelectItem>
                <SelectItem value="buffer">Buffer Analysis</SelectItem>
                <SelectItem value="polygon">Polygon Contains</SelectItem>
                <SelectItem value="custom">Custom SQL</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm font-medium text-slate-300 mb-2">Geographic Bounds</Label>
            <div className="grid grid-cols-2 gap-2">
              <Input
                type="number"
                placeholder="North"
                value={bounds.north}
                onChange={(e) => setBounds(prev => ({ ...prev, north: e.target.value }))}
                className="bg-dark border-surface-light text-base sm:text-sm h-12 sm:h-9"
                data-testid="input-north"
              />
              <Input
                type="number"
                placeholder="South"
                value={bounds.south}
                onChange={(e) => setBounds(prev => ({ ...prev, south: e.target.value }))}
                className="bg-dark border-surface-light text-base sm:text-sm h-12 sm:h-9"
                data-testid="input-south"
              />
              <Input
                type="number"
                placeholder="West"
                value={bounds.west}
                onChange={(e) => setBounds(prev => ({ ...prev, west: e.target.value }))}
                className="bg-dark border-surface-light text-base sm:text-sm h-12 sm:h-9"
                data-testid="input-west"
              />
              <Input
                type="number"
                placeholder="East"
                value={bounds.east}
                onChange={(e) => setBounds(prev => ({ ...prev, east: e.target.value }))}
                className="bg-dark border-surface-light text-base sm:text-sm h-12 sm:h-9"
                data-testid="input-east"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Filters Section */}
      <div className="p-4 border-b border-surface-light">
        <h3 className="text-sm font-semibold text-slate-300 mb-3">Filters</h3>
        
        <div className="space-y-3">
          <div>
            <Label className="text-sm text-slate-400 mb-1">Signal Strength (dBm)</Label>
            <div className="flex items-center space-x-2">
              <Input
                type="number"
                placeholder="-100"
                value={filters.signalMin}
                onChange={(e) => setFilters(prev => ({ ...prev, signalMin: e.target.value }))}
                className="w-20 bg-dark border-surface-light text-xs"
                data-testid="input-signal-min"
              />
              <span className="text-slate-500 text-xs">to</span>
              <Input
                type="number"
                placeholder="-20"
                value={filters.signalMax}
                onChange={(e) => setFilters(prev => ({ ...prev, signalMax: e.target.value }))}
                className="w-20 bg-dark border-surface-light text-xs"
                data-testid="input-signal-max"
              />
            </div>
          </div>

          <div>
            <Label className="text-sm text-slate-400 mb-1">Security</Label>
            <div className="space-y-1">
              {['WPA2', 'WPA3', 'WEP', 'Open'].map(security => (
                <div key={security} className="flex items-center space-x-2">
                  <Checkbox
                    id={security}
                    checked={filters.security.includes(security)}
                    onCheckedChange={(checked) => handleSecurityToggle(security, checked as boolean)}
                    data-testid={`checkbox-${security.toLowerCase()}`}
                  />
                  <Label htmlFor={security} className="text-xs">{security}</Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-sm text-slate-400 mb-1">Time Range</Label>
            <Select 
              value={filters.timeRange} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, timeRange: value }))}
              data-testid="select-time-range"
            >
              <SelectTrigger className="w-full bg-dark border-surface-light text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">Last 24 hours</SelectItem>
                <SelectItem value="week">Last week</SelectItem>
                <SelectItem value="month">Last month</SelectItem>
                <SelectItem value="custom">Custom range</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button 
          onClick={handleExecuteQuery}
          className="w-full bg-primary hover:bg-primary/80 mt-4 text-base sm:text-sm font-medium h-12 sm:h-10"
          data-testid="button-execute-query"
        >
          <Search className="w-5 h-5 sm:w-4 sm:h-4 mr-2" />
          Execute Query
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="p-4 flex-1">
        <h3 className="text-sm font-semibold text-slate-300 mb-3">Current Selection</h3>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between">
            <span className="text-slate-400">Networks:</span>
            <span className="text-slate-200" data-testid="text-network-count">
              {stats?.totalNetworks?.toLocaleString() || '0'}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Active:</span>
            <span className="text-slate-200" data-testid="text-active-count">
              {stats?.activeNetworks?.toLocaleString() || '0'}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Coverage:</span>
            <span className="text-slate-200" data-testid="text-coverage">
              {stats?.coverageArea?.toFixed(1) || '0'} km²
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
}
