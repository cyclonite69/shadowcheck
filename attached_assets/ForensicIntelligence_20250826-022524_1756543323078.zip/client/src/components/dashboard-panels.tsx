import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Shield, Wifi } from "lucide-react";
import type { Network, DetectionAlert } from "@shared/schema";

interface DashboardPanelsProps {
  networks: Network[];
  alerts: DetectionAlert[];
  stats?: {
    totalNetworks: number;
    activeNetworks: number;
    coverageArea: number;
    securityDistribution: { [key: string]: number };
  };
}

export default function DashboardPanels({ networks, alerts, stats }: DashboardPanelsProps) {
  // Calculate temporal data for chart simulation
  const generateTemporalData = () => {
    return Array.from({ length: 8 }, (_, i) => {
      const hour = new Date().getHours() - (7 - i);
      return {
        hour: hour < 0 ? 24 + hour : hour,
        count: Math.floor(Math.random() * 100) + 20
      };
    });
  };

  const temporalData = generateTemporalData();
  const maxCount = Math.max(...temporalData.map(d => d.count));

  const getSecurityPercentage = (security: string) => {
    if (!stats?.securityDistribution) return 0;
    const total = Object.values(stats.securityDistribution).reduce((sum, count) => sum + count, 0);
    return total > 0 ? Math.round((stats.securityDistribution[security] || 0) / total * 100) : 0;
  };

  const getSecurityColor = (security: string) => {
    switch (security.toLowerCase()) {
      case 'wpa2':
      case 'wpa3':
        return 'bg-success';
      case 'open':
        return 'bg-warning';
      case 'wep':
        return 'bg-error';
      default:
        return 'bg-primary';
    }
  };

  const formatTimeAgo = (date: Date | string | null) => {
    if (!date) return 'Unknown';
    const now = new Date();
    const past = new Date(date);
    const diffMs = now.getTime() - past.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    return `${Math.floor(diffMins / 1440)}d ago`;
  };

  return (
    <div className="h-80 bg-surface border-t border-surface-light p-4">
      <div className="grid grid-cols-4 gap-4 h-full">
        
        {/* Temporal Analysis Chart */}
        <Card className="col-span-2 bg-dark">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center">
              <Wifi className="w-4 h-4 mr-2" />
              Network Activity Over Time
            </CardTitle>
          </CardHeader>
          <CardContent className="h-full pb-4">
            <div className="h-full relative">
              <div className="absolute inset-0 flex items-end space-x-1 p-4">
                {temporalData.map((data, index) => (
                  <div key={index} className="flex-1 flex flex-col items-center">
                    <div 
                      className="bg-primary/60 w-full rounded-sm"
                      style={{ height: `${(data.count / maxCount) * 100}%` }}
                      data-testid={`chart-bar-${index}`}
                    />
                    <span className="text-xs text-slate-400 mt-1">
                      {data.hour}:00
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security Distribution */}
        <Card className="bg-dark">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center">
              <Shield className="w-4 h-4 mr-2" />
              Security Types
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {['WPA2', 'WPA3', 'Open', 'WEP'].map(security => {
              const percentage = getSecurityPercentage(security);
              return (
                <div key={security}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-400">{security}</span>
                    <span className="text-slate-200" data-testid={`text-${security.toLowerCase()}-percentage`}>
                      {percentage}%
                    </span>
                  </div>
                  <Progress 
                    value={percentage} 
                    className="h-1"
                    data-testid={`progress-${security.toLowerCase()}`}
                  />
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Surveillance Detection Alerts */}
        <Card className="bg-dark">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Detection Alerts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {alerts.length === 0 ? (
              <div className="text-xs text-slate-400 text-center py-4">
                No active alerts
              </div>
            ) : (
              alerts.slice(0, 3).map((alert, index) => (
                <div 
                  key={alert.id} 
                  className={`border rounded p-2 ${
                    alert.severity === 'critical' ? 'bg-error/20 border-error/40' :
                    alert.severity === 'warning' ? 'bg-warning/20 border-warning/40' :
                    'bg-primary/20 border-primary/40'
                  }`}
                  data-testid={`alert-${index}`}
                >
                  <div className="flex items-center justify-between">
                    <Badge 
                      variant="outline" 
                      className={`text-xs font-medium ${
                        alert.severity === 'critical' ? 'text-error border-error/40' :
                        alert.severity === 'warning' ? 'text-warning border-warning/40' :
                        'text-primary border-primary/40'
                      }`}
                    >
                      {alert.alertType}
                    </Badge>
                    <span className="text-xs text-slate-400">
                      {formatTimeAgo(alert.createdAt)}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1">
                    {alert.description || 'No description available'}
                  </p>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
