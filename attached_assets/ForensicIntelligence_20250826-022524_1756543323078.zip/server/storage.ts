import { type User, type InsertUser, type Network, type InsertNetwork, type DetectionAlert, type InsertDetectionAlert, type SpatialQuery, type InsertSpatialQuery, users, networks, detectionAlerts, spatialQueries } from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, gte, lte, ilike } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Network operations
  getNetworks(params?: {
    bounds?: { north: number; south: number; east: number; west: number };
    signalMin?: number;
    signalMax?: number;
    security?: string[];
    timeRange?: { start: Date; end: Date };
    limit?: number;
    offset?: number;
  }): Promise<Network[]>;
  createNetwork(network: InsertNetwork): Promise<Network>;
  updateNetwork(id: string, network: Partial<InsertNetwork>): Promise<Network>;
  
  // Spatial queries
  executeProximityQuery(point: { lat: number; lng: number }, radiusMeters: number): Promise<Network[]>;
  executeIntersectionQuery(polygon: string): Promise<Network[]>;
  executeBufferAnalysis(networkId: string, radiusMeters: number): Promise<Network[]>;
  
  // Detection alerts
  getDetectionAlerts(params?: { resolved?: boolean; severity?: string; limit?: number }): Promise<DetectionAlert[]>;
  createDetectionAlert(alert: InsertDetectionAlert): Promise<DetectionAlert>;
  resolveAlert(id: string): Promise<void>;
  
  // Spatial queries management
  getSpatialQueries(userId: string): Promise<SpatialQuery[]>;
  createSpatialQuery(query: InsertSpatialQuery): Promise<SpatialQuery>;
  
  // Statistics
  getNetworkStats(): Promise<{
    totalNetworks: number;
    activeNetworks: number;
    coverageArea: number;
    securityDistribution: { [key: string]: number };
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getNetworks(params?: {
    bounds?: { north: number; south: number; east: number; west: number };
    signalMin?: number;
    signalMax?: number;
    security?: string[];
    timeRange?: { start: Date; end: Date };
    limit?: number;
    offset?: number;
  }): Promise<Network[]> {
    let query = db.select().from(networks);
    const conditions = [];

    if (params?.bounds) {
      const { north, south, east, west } = params.bounds;
      conditions.push(
        and(
          gte(networks.latitude, south.toString()),
          lte(networks.latitude, north.toString()),
          gte(networks.longitude, west.toString()),
          lte(networks.longitude, east.toString())
        )
      );
    }

    if (params?.signalMin !== undefined) {
      conditions.push(gte(networks.signalStrength, params.signalMin));
    }

    if (params?.signalMax !== undefined) {
      conditions.push(lte(networks.signalStrength, params.signalMax));
    }

    if (params?.security?.length) {
      conditions.push(sql`${networks.security} = ANY(${params.security})`);
    }

    if (params?.timeRange) {
      conditions.push(
        and(
          gte(networks.lastSeen, params.timeRange.start),
          lte(networks.lastSeen, params.timeRange.end)
        )
      );
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    query = query.orderBy(desc(networks.lastSeen));

    if (params?.limit) {
      query = query.limit(params.limit);
    }

    if (params?.offset) {
      query = query.offset(params.offset);
    }

    return await query;
  }

  async createNetwork(network: InsertNetwork): Promise<Network> {
    const [createdNetwork] = await db
      .insert(networks)
      .values({
        ...network,
        location: network.latitude && network.longitude 
          ? sql`ST_SetSRID(ST_MakePoint(${network.longitude}, ${network.latitude}), 4326)`
          : null,
      })
      .returning();
    return createdNetwork;
  }

  async updateNetwork(id: string, network: Partial<InsertNetwork>): Promise<Network> {
    const updateData: any = { ...network };
    
    if (network.latitude && network.longitude) {
      updateData.location = sql`ST_SetSRID(ST_MakePoint(${network.longitude}, ${network.latitude}), 4326)`;
    }

    const [updatedNetwork] = await db
      .update(networks)
      .set(updateData)
      .where(eq(networks.id, id))
      .returning();
    return updatedNetwork;
  }

  async executeProximityQuery(point: { lat: number; lng: number }, radiusMeters: number): Promise<Network[]> {
    return await db.select().from(networks).where(
      sql`ST_DWithin(
        ${networks.location},
        ST_SetSRID(ST_MakePoint(${point.lng}, ${point.lat}), 4326)::geography,
        ${radiusMeters}
      )`
    );
  }

  async executeIntersectionQuery(polygon: string): Promise<Network[]> {
    return await db.select().from(networks).where(
      sql`ST_Intersects(${networks.location}, ST_GeomFromText(${polygon}, 4326))`
    );
  }

  async executeBufferAnalysis(networkId: string, radiusMeters: number): Promise<Network[]> {
    return await db.select().from(networks).where(
      sql`ST_DWithin(
        ${networks.location},
        (SELECT ST_Buffer(${networks.location}::geography, ${radiusMeters}) FROM ${networks} WHERE id = ${networkId})::geometry,
        0
      )`
    );
  }

  async getDetectionAlerts(params?: { resolved?: boolean; severity?: string; limit?: number }): Promise<DetectionAlert[]> {
    let query = db.select().from(detectionAlerts);
    const conditions = [];

    if (params?.resolved !== undefined) {
      conditions.push(eq(detectionAlerts.resolved, params.resolved));
    }

    if (params?.severity) {
      conditions.push(eq(detectionAlerts.severity, params.severity));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    query = query.orderBy(desc(detectionAlerts.createdAt));

    if (params?.limit) {
      query = query.limit(params.limit);
    }

    return await query;
  }

  async createDetectionAlert(alert: InsertDetectionAlert): Promise<DetectionAlert> {
    const [createdAlert] = await db
      .insert(detectionAlerts)
      .values({
        ...alert,
        location: alert.metadata 
          ? sql`ST_SetSRID(ST_MakePoint(${JSON.parse(alert.metadata).longitude || 0}, ${JSON.parse(alert.metadata).latitude || 0}), 4326)`
          : null,
      })
      .returning();
    return createdAlert;
  }

  async resolveAlert(id: string): Promise<void> {
    await db
      .update(detectionAlerts)
      .set({ resolved: true })
      .where(eq(detectionAlerts.id, id));
  }

  async getSpatialQueries(userId: string): Promise<SpatialQuery[]> {
    return await db
      .select()
      .from(spatialQueries)
      .where(eq(spatialQueries.userId, userId))
      .orderBy(desc(spatialQueries.createdAt));
  }

  async createSpatialQuery(query: InsertSpatialQuery): Promise<SpatialQuery> {
    const [createdQuery] = await db
      .insert(spatialQueries)
      .values(query)
      .returning();
    return createdQuery;
  }

  async getNetworkStats(): Promise<{
    totalNetworks: number;
    activeNetworks: number;
    coverageArea: number;
    securityDistribution: { [key: string]: number };
  }> {
    const [totalResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(networks);

    const [activeResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(networks)
      .where(eq(networks.isActive, true));

    const securityResults = await db
      .select({
        security: networks.security,
        count: sql<number>`count(*)`
      })
      .from(networks)
      .groupBy(networks.security);

    const securityDistribution: { [key: string]: number } = {};
    securityResults.forEach(result => {
      if (result.security) {
        securityDistribution[result.security] = result.count;
      }
    });

    return {
      totalNetworks: totalResult.count,
      activeNetworks: activeResult.count,
      coverageArea: 0, // Would need complex PostGIS calculation
      securityDistribution,
    };
  }
}

export const storage = new DatabaseStorage();
