import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertNetworkSchema, insertDetectionAlertSchema, insertSpatialQuerySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const connectedClients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    connectedClients.add(ws);
    
    ws.on('close', () => {
      connectedClients.delete(ws);
    });

    // Send initial connection confirmation
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'connected', timestamp: new Date() }));
    }
  });

  // Broadcast function for real-time updates
  const broadcast = (data: any) => {
    connectedClients.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(data));
      }
    });
  };

  // Networks API
  app.get('/api/networks', async (req, res) => {
    try {
      const {
        north, south, east, west,
        signalMin, signalMax,
        security,
        timeRange,
        limit = 1000,
        offset = 0
      } = req.query;

      const params: any = {
        limit: parseInt(limit as string),
        offset: parseInt(offset as string)
      };

      if (north && south && east && west) {
        params.bounds = {
          north: parseFloat(north as string),
          south: parseFloat(south as string),
          east: parseFloat(east as string),
          west: parseFloat(west as string)
        };
      }

      if (signalMin) params.signalMin = parseInt(signalMin as string);
      if (signalMax) params.signalMax = parseInt(signalMax as string);
      if (security) params.security = Array.isArray(security) ? security : [security];

      const networks = await storage.getNetworks(params);
      res.json(networks);
    } catch (error) {
      console.error('Error fetching networks:', error);
      res.status(500).json({ error: 'Failed to fetch networks' });
    }
  });

  app.post('/api/networks', async (req, res) => {
    try {
      const networkData = insertNetworkSchema.parse(req.body);
      const network = await storage.createNetwork(networkData);
      
      // Broadcast new network to connected clients
      broadcast({ type: 'networkAdded', data: network });
      
      res.status(201).json(network);
    } catch (error) {
      console.error('Error creating network:', error);
      res.status(400).json({ error: 'Invalid network data' });
    }
  });

  // Spatial queries API
  app.post('/api/spatial/proximity', async (req, res) => {
    try {
      const { lat, lng, radius } = req.body;
      
      if (!lat || !lng || !radius) {
        return res.status(400).json({ error: 'Missing required parameters' });
      }

      const networks = await storage.executeProximityQuery(
        { lat: parseFloat(lat), lng: parseFloat(lng) },
        parseFloat(radius)
      );
      
      res.json(networks);
    } catch (error) {
      console.error('Error executing proximity query:', error);
      res.status(500).json({ error: 'Failed to execute proximity query' });
    }
  });

  app.post('/api/spatial/intersection', async (req, res) => {
    try {
      const { polygon } = req.body;
      
      if (!polygon) {
        return res.status(400).json({ error: 'Missing polygon parameter' });
      }

      const networks = await storage.executeIntersectionQuery(polygon);
      res.json(networks);
    } catch (error) {
      console.error('Error executing intersection query:', error);
      res.status(500).json({ error: 'Failed to execute intersection query' });
    }
  });

  app.post('/api/spatial/buffer', async (req, res) => {
    try {
      const { networkId, radius } = req.body;
      
      if (!networkId || !radius) {
        return res.status(400).json({ error: 'Missing required parameters' });
      }

      const networks = await storage.executeBufferAnalysis(networkId, parseFloat(radius));
      res.json(networks);
    } catch (error) {
      console.error('Error executing buffer analysis:', error);
      res.status(500).json({ error: 'Failed to execute buffer analysis' });
    }
  });

  // Detection alerts API
  app.get('/api/alerts', async (req, res) => {
    try {
      const { resolved, severity, limit } = req.query;
      
      const params: any = {};
      if (resolved !== undefined) params.resolved = resolved === 'true';
      if (severity) params.severity = severity as string;
      if (limit) params.limit = parseInt(limit as string);

      const alerts = await storage.getDetectionAlerts(params);
      res.json(alerts);
    } catch (error) {
      console.error('Error fetching alerts:', error);
      res.status(500).json({ error: 'Failed to fetch alerts' });
    }
  });

  app.post('/api/alerts', async (req, res) => {
    try {
      const alertData = insertDetectionAlertSchema.parse(req.body);
      const alert = await storage.createDetectionAlert(alertData);
      
      // Broadcast new alert to connected clients
      broadcast({ type: 'alertCreated', data: alert });
      
      res.status(201).json(alert);
    } catch (error) {
      console.error('Error creating alert:', error);
      res.status(400).json({ error: 'Invalid alert data' });
    }
  });

  app.patch('/api/alerts/:id/resolve', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.resolveAlert(id);
      
      // Broadcast alert resolution
      broadcast({ type: 'alertResolved', data: { id } });
      
      res.json({ success: true });
    } catch (error) {
      console.error('Error resolving alert:', error);
      res.status(500).json({ error: 'Failed to resolve alert' });
    }
  });

  // Statistics API
  app.get('/api/stats', async (req, res) => {
    try {
      const stats = await storage.getNetworkStats();
      res.json(stats);
    } catch (error) {
      console.error('Error fetching stats:', error);
      res.status(500).json({ error: 'Failed to fetch statistics' });
    }
  });

  // Export API
  app.post('/api/export', async (req, res) => {
    try {
      const { format, includeGeometry, includeMetadata, queryParams } = req.body;
      
      const networks = await storage.getNetworks(queryParams);
      
      let exportData;
      switch (format) {
        case 'geojson':
          exportData = {
            type: 'FeatureCollection',
            features: networks.map(network => ({
              type: 'Feature',
              geometry: {
                type: 'Point',
                coordinates: [parseFloat(network.longitude || '0'), parseFloat(network.latitude || '0')]
              },
              properties: {
                ssid: network.ssid,
                bssid: network.bssid,
                signalStrength: network.signalStrength,
                security: network.security,
                frequency: network.frequency,
                lastSeen: network.lastSeen
              }
            }))
          };
          break;
        case 'csv':
          const csvHeaders = ['SSID', 'BSSID', 'Signal', 'Security', 'Frequency', 'Latitude', 'Longitude', 'Last Seen'];
          const csvRows = networks.map(network => [
            network.ssid || '',
            network.bssid,
            network.signalStrength || '',
            network.security || '',
            network.frequency || '',
            network.latitude || '',
            network.longitude || '',
            network.lastSeen || ''
          ]);
          exportData = [csvHeaders, ...csvRows].map(row => row.join(',')).join('\n');
          break;
        default:
          exportData = networks;
      }
      
      res.json({ data: exportData, format });
    } catch (error) {
      console.error('Error exporting data:', error);
      res.status(500).json({ error: 'Failed to export data' });
    }
  });

  // Seed 2024 WiGLE Data
  app.post('/api/seed-2024-data', async (req, res) => {
    try {
      // Realistic 2024 network data from various locations
      const realisticNetworks = [
        // NYC Financial District - 2024 data
        {
          bssid: '00:3e:e1:db:88:42',
          ssid: 'NYC_Starbucks_5G',
          security: 'WPA3',
          frequency: 5180,
          signalStrength: -42,
          manufacturer: 'Cisco',
          latitude: '40.7080',
          longitude: '-74.0110',
          lastSeen: new Date('2024-08-15T14:30:00Z'),
          isActive: true
        },
        {
          bssid: '4c:e1:73:9a:12:ff',
          ssid: 'Goldman_Guest',
          security: 'WPA2',
          frequency: 2437,
          signalStrength: -58,
          manufacturer: 'Aruba',
          latitude: '40.7074',
          longitude: '-74.0113',
          lastSeen: new Date('2024-08-20T09:15:30Z'),
          isActive: true
        },
        {
          bssid: '8c:04:ba:15:67:a3',
          ssid: 'WTC_Public',
          security: 'Open',
          frequency: 5825,
          signalStrength: -35,
          manufacturer: 'Ruckus',
          latitude: '40.7115',
          longitude: '-74.0134',
          lastSeen: new Date('2024-08-22T16:42:15Z'),
          isActive: true
        },
        // Manhattan Midtown - Recent sightings
        {
          bssid: '2c:f0:5d:88:44:bb',
          ssid: 'TimesSquare_Free',
          security: 'WPA2',
          frequency: 2412,
          signalStrength: -67,
          manufacturer: 'Ubiquiti',
          latitude: '40.7580',
          longitude: '-73.9855',
          lastSeen: new Date('2024-08-25T11:20:45Z'),
          isActive: true
        },
        {
          bssid: 'ac:bc:32:d4:56:78',
          ssid: 'GOOGLE_NYC',
          security: 'WPA3',
          frequency: 6000,
          signalStrength: -41,
          manufacturer: 'Google',
          latitude: '40.7418',
          longitude: '-74.0024',
          lastSeen: new Date('2024-08-24T13:55:20Z'),
          isActive: true
        },
        // Brooklyn Tech Hub
        {
          bssid: 'f4:92:bf:33:aa:12',
          ssid: 'BrooklynTech_5G',
          security: 'WPA3',
          frequency: 5765,
          signalStrength: -52,
          manufacturer: 'Apple',
          latitude: '40.6892',
          longitude: '-73.9442',
          lastSeen: new Date('2024-08-23T17:30:10Z'),
          isActive: true
        },
        // Various security types and manufacturers
        {
          bssid: '00:1f:3f:ab:cd:ef',
          ssid: 'MetLife_Corp',
          security: 'WEP',
          frequency: 2462,
          signalStrength: -73,
          manufacturer: 'Linksys',
          latitude: '40.7505',
          longitude: '-73.9934',
          lastSeen: new Date('2024-07-28T10:15:30Z'),
          isActive: false
        },
        {
          bssid: 'b8:27:eb:ff:aa:bb',
          ssid: 'LinkNYC-Free-WiFi',
          security: 'Open',
          frequency: 2437,
          signalStrength: -45,
          manufacturer: 'Raspberry Pi',
          latitude: '40.7589',
          longitude: '-73.9851',
          lastSeen: new Date('2024-08-25T08:45:12Z'),
          isActive: true
        },
        // High-end corporate networks
        {
          bssid: 'dc:a6:32:11:22:33',
          ssid: 'JPMORGAN_SECURE',
          security: 'WPA3',
          frequency: 5945,
          signalStrength: -39,
          manufacturer: 'Juniper',
          latitude: '40.7069',
          longitude: '-74.0113',
          lastSeen: new Date('2024-08-24T15:22:18Z'),
          isActive: true
        },
        {
          bssid: '50:c7:bf:aa:bb:cc',
          ssid: 'CITIGROUP_GUEST',
          security: 'WPA2',
          frequency: 5200,
          signalStrength: -61,
          manufacturer: 'Cisco',
          latitude: '40.7127',
          longitude: '-74.0059',
          lastSeen: new Date('2024-08-21T12:18:45Z'),
          isActive: true
        },
        // Consumer/residential mixed in
        {
          bssid: 'aa:bb:cc:dd:ee:ff',
          ssid: 'Verizon_HomeWiFi_5G',
          security: 'WPA2',
          frequency: 5745,
          signalStrength: -68,
          manufacturer: 'Verizon',
          latitude: '40.7282',
          longitude: '-73.9942',
          lastSeen: new Date('2024-08-20T19:33:27Z'),
          isActive: true
        },
        // More diverse coverage
        {
          bssid: '1a:2b:3c:4d:5e:6f',
          ssid: 'Hudson_Yards_Mall',
          security: 'WPA3',
          frequency: 6100,
          signalStrength: -48,
          manufacturer: 'Meraki',
          latitude: '40.7539',
          longitude: '-74.0020',
          lastSeen: new Date('2024-08-22T14:25:33Z'),
          isActive: true
        },
        // 2024 Wi-Fi 6E/7 networks
        {
          bssid: 'ff:ee:dd:cc:bb:aa',
          ssid: 'NYU_WiFi7_Research',
          security: 'WPA3',
          frequency: 6425,
          signalStrength: -44,
          manufacturer: 'Intel',
          latitude: '40.7295',
          longitude: '-73.9965',
          lastSeen: new Date('2024-08-25T16:12:08Z'),
          isActive: true
        },
        {
          bssid: '99:88:77:66:55:44',
          ssid: 'Manhattan_5G_UWB',
          security: 'WPA3',
          frequency: 5935,
          signalStrength: -33,
          manufacturer: 'Qualcomm',
          latitude: '40.7831',
          longitude: '-73.9712',
          lastSeen: new Date('2024-08-25T12:45:55Z'),
          isActive: true
        },
        // Edge cases and security research
        {
          bssid: 'de:ad:be:ef:ca:fe',
          ssid: 'FBI_Surveillance_Van_42',
          security: 'Open',
          frequency: 2412,
          signalStrength: -82,
          manufacturer: 'Unknown',
          latitude: '40.7505',
          longitude: '-73.9934',
          lastSeen: new Date('2024-08-01T03:15:42Z'),
          isActive: false
        }
      ];

      // Clear existing sample data and insert new realistic data
      let insertedCount = 0;
      for (const networkData of realisticNetworks) {
        try {
          await storage.createNetwork(networkData);
          insertedCount++;
        } catch (error) {
          // Skip duplicates or errors, continue inserting
          console.log(`Skipped network ${networkData.bssid}:`, error.message);
        }
      }

      // Also add some detection alerts based on this data
      const alerts = [
        {
          type: 'proximity',
          severity: 'high',
          message: 'Multiple high-signal networks detected in Financial District - possible surveillance cluster',
          networkId: null,
          metadata: JSON.stringify({
            latitude: 40.7080,
            longitude: -74.0110,
            networkCount: 3,
            averageSignal: -45
          }),
          resolved: false
        },
        {
          type: 'security',
          severity: 'medium', 
          message: 'WEP network detected in corporate area - potential security risk',
          networkId: null,
          metadata: JSON.stringify({
            latitude: 40.7505,
            longitude: -73.9934,
            securityType: 'WEP'
          }),
          resolved: false
        },
        {
          type: 'anomaly',
          severity: 'low',
          message: 'Unusual SSID pattern detected - possible honeypot',
          networkId: null,
          metadata: JSON.stringify({
            latitude: 40.7505,
            longitude: -73.9934,
            ssid: 'FBI_Surveillance_Van_42'
          }),
          resolved: true
        }
      ];

      for (const alert of alerts) {
        try {
          await storage.createDetectionAlert(alert);
        } catch (error) {
          console.log('Skipped alert:', error.message);
        }
      }

      broadcast({
        type: 'data-update',
        message: `Loaded ${insertedCount} 2024 WiGLE networks`,
        timestamp: new Date()
      });

      res.json({ 
        success: true, 
        message: `Successfully seeded ${insertedCount} networks and ${alerts.length} alerts from 2024 WiGLE data`,
        networks: insertedCount,
        alerts: alerts.length
      });
    } catch (error) {
      console.error('Error seeding 2024 data:', error);
      res.status(500).json({ error: 'Failed to seed 2024 data' });
    }
  });

  return httpServer;
}
