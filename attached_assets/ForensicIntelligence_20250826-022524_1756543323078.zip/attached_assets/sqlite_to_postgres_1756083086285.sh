#!/bin/bash
set -euo pipefail

DB_NAME="wigledb_s22"
SQLITE_FILE="s22.sqlite"
SCHEMA_FILE="pg_schema_s22_final_clean.sql"
PG_USER="postgres"

echo "📛 Dropping and recreating database..."
dropdb -U "$PG_USER" "$DB_NAME" || true
createdb -U "$PG_USER" "$DB_NAME"

echo "🧹 Converting SQLite schema to PostgreSQL..."
sqlite3 "$SQLITE_FILE" .dump | \
  sed -e 's/\bINTEGER PRIMARY KEY AUTOINCREMENT\b/SERIAL PRIMARY KEY/g' \
      -e 's/\bINTEGER PRIMARY KEY\b/SERIAL PRIMARY KEY/g' \
      -e 's/\b[Ll]ong\b/BIGINT/g' \
      -e 's/\b[Dd]ouble\b/DOUBLE PRECISION/g' \
      -e 's/\b[Ff]loat\b/REAL/g' \
      -e 's/\b[Bb]lob\b/BYTEA/g' \
      -e '/^PRAGMA/d' \
      -e '/^BEGIN TRANSACTION/d' \
      -e '/^COMMIT/d' \
      -e 's/\b[Aa][Uu][Tt][Oo][Ii][Nn][Cc][Rr][Ee][Mm][Ee][Nn][Tt]\b//g' \
      -e '/sqlite_sequence/d' \
  > "$SCHEMA_FILE"

echo "🧱 Loading cleaned schema..."
psql -v ON_ERROR_STOP=1 -U "$PG_USER" -d "$DB_NAME" -f "$SCHEMA_FILE"

echo "📦 Importing data..."
for tbl in $(sqlite3 "$SQLITE_FILE" ".tables"); do
  echo "Importing $tbl..."
  sqlite3 "$SQLITE_FILE" -header -csv "SELECT * FROM \"$tbl\";" | \
    psql -U "$PG_USER" -d "$DB_NAME" -c "\copy \"$tbl\" FROM STDIN WITH CSV HEADER"
	done

echo "🔧 Fixing sequences..."
psql -U "$PG_USER" -d "$DB_NAME" -Atc "
SELECT 'SELECT setval(' ||
       quote_literal(pg_get_serial_sequence(quote_ident(schemaname) || '.' || quote_ident(tablename), a.attname)) ||
       ', COALESCE(MAX(' || quote_ident(a.attname) || '), 1)) FROM ' ||
       quote_ident(schemaname) || '.' || quote_ident(tablename) || ';'
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
JOIN pg_attribute a ON a.attrelid = c.oid
JOIN pg_attrdef d ON a.attrelid = d.adrelid AND a.attnum = d.adnum
WHERE d.adsrc LIKE 'nextval%' AND c.relkind = 'r';
" | psql -U "$PG_USER" -d "$DB_NAME"

echo "✅ All done! Schema and data loaded cleanly into $DB_NAME"

