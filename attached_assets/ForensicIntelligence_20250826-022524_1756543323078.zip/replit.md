# WiGLE Spatial Analytics Platform

## Overview

This is a full-stack web application for geospatial analysis of Wi-Fi network data, inspired by WiGLE (Wireless Geographic Logging Engine). The platform provides real-time visualization, spatial querying, and analytics capabilities for wireless network detection data. It features an interactive map interface with clustering, filtering, and export functionality, along with a comprehensive dashboard for monitoring network statistics and security analysis.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern component patterns
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui design system for consistent, accessible components
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Language**: TypeScript throughout for consistent type checking
- **Real-time Communication**: WebSocket server for live data updates and notifications
- **Development**: Hot module replacement and runtime error overlay for development efficiency

### Database Layer
- **ORM**: Drizzle ORM for type-safe database operations and schema management
- **Database**: PostgreSQL with PostGIS extensions for geospatial data handling
- **Connection**: Neon serverless PostgreSQL for scalable cloud database hosting
- **Spatial Indexing**: GiST indexes on geometry columns for efficient spatial queries
- **Schema**: Structured tables for networks, detection alerts, spatial queries, and user management

### Mapping and Visualization
- **Map Engine**: Mapbox GL JS for interactive vector maps with WebGL rendering
- **Geospatial Features**: Point clustering, heatmaps, and custom markers for network visualization
- **Coordinate Systems**: Support for both decimal degrees and DMS coordinate formats
- **Map Styles**: Multiple map styles (dark, light, satellite) with dynamic switching

### Authentication and Security
- **Session Management**: Connect-pg-simple for PostgreSQL-backed session storage
- **Data Validation**: Zod schemas for runtime type validation and API request/response validation
- **Security Headers**: Proper CORS and security middleware configuration

### Real-time Features
- **WebSocket Integration**: Live updates for new network detections and alerts
- **Event Broadcasting**: Server-side event broadcasting to connected clients
- **Connection Management**: Automatic reconnection and connection state handling

## External Dependencies

### Core Services
- **Neon Database**: Serverless PostgreSQL hosting with automatic scaling
- **Mapbox**: Map tiles, geocoding services, and spatial visualization APIs

### Development Tools
- **Replit Integration**: Custom Vite plugins for Replit-specific development features
- **Runtime Error Handling**: Replit runtime error modal for enhanced debugging

### NPM Packages
- **UI Framework**: React ecosystem with Radix UI and Lucide icons
- **Data Fetching**: TanStack Query for efficient server state management
- **Form Handling**: React Hook Form with Hookform resolvers for validation
- **Styling**: Tailwind CSS with class-variance-authority for component variants
- **Date Handling**: date-fns for date manipulation and formatting
- **WebSocket**: Native WebSocket API with custom reconnection logic
- **Geospatial**: Mapbox GL JS for map rendering and spatial interactions

### Build and Development
- **Build System**: Vite with ESBuild for fast compilation
- **TypeScript**: Strict type checking across frontend and backend
- **Hot Reload**: Development server with instant updates
- **Asset Management**: Static asset serving and optimization