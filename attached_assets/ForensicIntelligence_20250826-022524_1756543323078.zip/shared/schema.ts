import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, integer, boolean, geometry, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const networks = pgTable("networks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ssid: text("ssid"),
  bssid: varchar("bssid", { length: 17 }).notNull(),
  signalStrength: integer("signal_strength"),
  frequency: decimal("frequency", { precision: 8, scale: 2 }),
  security: text("security"),
  encryption: text("encryption"),
  channel: integer("channel"),
  location: geometry("location", { type: "point", mode: "xy" }),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  altitude: decimal("altitude", { precision: 8, scale: 2 }),
  firstSeen: timestamp("first_seen").defaultNow(),
  lastSeen: timestamp("last_seen").defaultNow(),
  isActive: boolean("is_active").default(true),
  deviceType: text("device_type"),
  manufacturer: text("manufacturer"),
  capabilities: text("capabilities"),
}, (table) => ({
  locationIdx: index("location_idx").using("gist", table.location),
  bssidIdx: index("bssid_idx").on(table.bssid),
  lastSeenIdx: index("last_seen_idx").on(table.lastSeen),
}));

export const detectionAlerts = pgTable("detection_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  networkId: varchar("network_id").references(() => networks.id),
  alertType: text("alert_type").notNull(),
  severity: text("severity").notNull(),
  description: text("description"),
  metadata: text("metadata"),
  location: geometry("location", { type: "point", mode: "xy" }),
  createdAt: timestamp("created_at").defaultNow(),
  resolved: boolean("resolved").default(false),
});

export const spatialQueries = pgTable("spatial_queries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  queryName: text("query_name"),
  queryType: text("query_type").notNull(),
  parameters: text("parameters"),
  bounds: geometry("bounds", { type: "polygon", mode: "xy" }),
  createdAt: timestamp("created_at").defaultNow(),
  lastExecuted: timestamp("last_executed"),
});

export const networksRelations = relations(networks, ({ many }) => ({
  alerts: many(detectionAlerts),
}));

export const detectionAlertsRelations = relations(detectionAlerts, ({ one }) => ({
  network: one(networks, {
    fields: [detectionAlerts.networkId],
    references: [networks.id],
  }),
}));

export const usersRelations = relations(users, ({ many }) => ({
  queries: many(spatialQueries),
}));

export const spatialQueriesRelations = relations(spatialQueries, ({ one }) => ({
  user: one(users, {
    fields: [spatialQueries.userId],
    references: [users.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertNetworkSchema = createInsertSchema(networks).omit({
  id: true,
  firstSeen: true,
  lastSeen: true,
});

export const insertDetectionAlertSchema = createInsertSchema(detectionAlerts).omit({
  id: true,
  createdAt: true,
});

export const insertSpatialQuerySchema = createInsertSchema(spatialQueries).omit({
  id: true,
  createdAt: true,
  lastExecuted: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertNetwork = z.infer<typeof insertNetworkSchema>;
export type Network = typeof networks.$inferSelect;
export type InsertDetectionAlert = z.infer<typeof insertDetectionAlertSchema>;
export type DetectionAlert = typeof detectionAlerts.$inferSelect;
export type InsertSpatialQuery = z.infer<typeof insertSpatialQuerySchema>;
export type SpatialQuery = typeof spatialQueries.$inferSelect;
